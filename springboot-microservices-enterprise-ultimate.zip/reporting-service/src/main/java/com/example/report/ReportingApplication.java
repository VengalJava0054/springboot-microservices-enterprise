
@SpringBootApplication
public class ReportingApplication {
  public static void main(String[] args){
    SpringApplication.run(ReportingApplication.class,args);
  }
}
