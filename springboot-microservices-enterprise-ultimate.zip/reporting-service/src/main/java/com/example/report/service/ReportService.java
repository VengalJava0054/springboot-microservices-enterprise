
@Service
public class ReportService {

  public byte[] generateExcel() throws Exception {
    Workbook wb = new XSSFWorkbook();
    Sheet sheet = wb.createSheet("Report");
    Row row = sheet.createRow(0);
    row.createCell(0).setCellValue("Sample Report");
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    wb.write(out);
    return out.toByteArray();
  }

  public byte[] generatePdf() throws Exception {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    PdfWriter writer = new PdfWriter(out);
    PdfDocument pdf = new PdfDocument(writer);
    Document doc = new Document(pdf);
    doc.add(new Paragraph("Sample PDF Report"));
    doc.close();
    return out.toByteArray();
  }
}
